/* Data filtration */
document.addEventListener('DOMContentLoaded', function() {
    // Set the initial filter to "Directors"
    filter(document.querySelector('.filter-bttn[data-filtertarget="directors"]'));
});

function filter(element) {
    // Get all filter buttons and remove the active class
    var filterButtons = document.querySelectorAll('.filter-bttn');
    filterButtons.forEach(function(button) {
        button.classList.remove('active');
    });

    // Add the active class to the clicked button
    element.classList.add('active');

    // Get the target filter category from the clicked button
    var target = element.getAttribute('data-filtertarget');

    // Get all content items
    var allItems = document.querySelectorAll('.directorsfilter');

    // Show or hide content items based on the selected filter
    allItems.forEach(function(item) {
        if (target === 'all' || item.classList.contains(target)) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

/*Data filtration code2*/
function filter(element) {
    const filterTarget = element.getAttribute('data-filtertarget');
    const allContents = document.querySelectorAll('.allcontent');
    const filterButtons = document.querySelectorAll('.filter-bttn');
    
    // Remove 'active' class from all buttons
    filterButtons.forEach(button => button.classList.remove('active'));
    
    // Add 'active' class to the clicked button
    element.classList.add('active');
    
    // Show or hide content based on the filter
    allContents.forEach(content => {
        if (filterTarget === 'all' || content.querySelector(`.${filterTarget}`)) {
            content.style.display = 'block';
        } else {
            content.style.display = 'none';
        }
    });
}

// Initial display of all items
document.addEventListener('DOMContentLoaded', () => {
    const filterAllButton = document.querySelector('.filter-bttn[data-filtertarget="all"]');
    filter(filterAllButton);
});


/* FAQs Accordian*/
function toggleFAQ(element) {
      const faqItem = element.parentElement;
      faqItem.classList.toggle('open');
      const icon = element.querySelector('.faq-icon');
      icon.textContent = faqItem.classList.contains('open') ? '-' : '+';
    }
    
    // Function to open the first FAQ item by default
    function openFirstFAQ() {
      const firstFAQItem = document.querySelector('.faq .faq-item');
      if (firstFAQItem) {
        firstFAQItem.classList.add('open');
        const icon = firstFAQItem.querySelector('.faq-icon');
        if (icon) {
          icon.textContent = '-';
        }
      }
    }
    
    // Run the function when the page loads
    window.onload = openFirstFAQ;
